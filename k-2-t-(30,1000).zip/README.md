# How to run

1. Create directories '/frames' and '/processed'

2. Run all of the cells in the file in the same way that you would run any jupyter notebook file.

3. Please read the pdf entitled Values for k and t compared to view a snippet of the experiments I conducted with the hyper parameters.
